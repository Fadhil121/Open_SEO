# Maintainers

This document covers maintainer-only workflow notes that do not belong in the public project README.

## Release updates

GitHub Releases are the main user-facing update channel for OpenSEO.

- Ask interested users to watch the repo and enable release notifications.
- Do not treat stars as a contact list; GitHub does not expose a way to message stargazers directly.

## Release notes workflow

Generate notes from commits since the latest semver tag:

```sh
pnpm release:notes
```

Useful variants:

```sh
pnpm release:notes -- --from v0.0.1 --to HEAD
pnpm release:notes -- --draft v0.0.2
```

Supported inputs:

- `--from <tag>`: start changelog generation from a specific tag
- `--to <ref>`: end at a specific ref, default is `HEAD`
- `--draft <tag>`: create a GitHub draft release for that tag using the generated notes
- `--repo <owner/repo>`: override the GitHub repo
- `--help`: show help

The generator:

- uses commits since the latest semver tag by default
- filters out maintenance-only commits like `chore:`, `ci:`, `test:`, `build:`, and `release:`
- groups the remaining changes into short user-facing sections
- can create a draft GitHub release when `--draft` is provided

Store finalized notes in `docs/release-notes/` as versioned Markdown files such as `docs/release-notes/v0.0.2.md`.

Recommended release flow:

```sh
pnpm -s release:notes
# edit and save the final copy in docs/release-notes/v0.0.2.md
gh release create v0.0.2 --target main --title v0.0.2 --notes-file docs/release-notes/v0.0.2.md
```

For now, prefer patch releases while the project is still in rapid early development unless there is a clear reason to cut a minor or major release.

## Docker edition runtime check

The standalone Docker image runs on celld, which implements only part of the Workers runtime contract. Before a release that changes `deploy/standalone/` or bumps `CELLD_VERSION`, build the image and check that celld still does what OpenSEO relies on (about a minute):

```sh
docker build -f deploy/standalone/Dockerfile -t openseo-standalone:check .
pnpm test:standalone:runtime openseo-standalone:check
```

A `no` on a required line is a regression to fix before the release. The `(upstream)` lines turn to `yes` once celld fixes a known gap; then the matching workaround (`src/server/workflows/yieldingStep.ts` for denoland/celld#299, `src/server/standalone/aes-kw.ts` for denoland/celld#295) can go.
